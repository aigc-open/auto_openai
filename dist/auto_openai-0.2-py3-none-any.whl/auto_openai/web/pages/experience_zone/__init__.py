import os
base_url = os.environ.get(
        "OPENAI_BASE_URL", "http://127.0.0.1:9000/openai/v1")
api_key = "xxxx"