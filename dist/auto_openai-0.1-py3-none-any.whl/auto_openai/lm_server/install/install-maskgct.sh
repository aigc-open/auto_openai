apt-get install espeak-ng -y
cd /workspace && git clone https://gitee.com/lijiacai/MaskGCT.git && cd /workspace/MaskGCT && bash ./env.sh && bash ./models/tts/maskgct/env.sh