import os
project_path = os.path.dirname(os.path.abspath(__file__))